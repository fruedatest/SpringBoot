package com.project.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project004ApplicationTests {

	@Test
	void contextLoads() {
	}

}
